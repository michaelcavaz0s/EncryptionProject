// DecryptData.cpp
//
// THis file uses the input data and key information to decrypt the input data
//

#include "Main.h"

//////////////////////////////////////////////////////////////////////////////////////////////////
// code to decrypt the data as specified by the project assignment
int decryptData(char *data, int dataLength)
{
	int resulti = 0;

	gdebug1 = 0;					// a couple of global variables that could be used for debugging
	gdebug2 = 0;					// also can have a breakpoint in C code

	// You can not declare any local variables in C, but should use resulti to indicate any errors
	// Set up the stack frame and assign variables in assembly if you need to do so
	// access the parameters BEFORE setting up your own stack frame
	// Also, you cannot use a lot of global variables - work with registers

	__asm {
		// you will need to reference some of these global variables
		// (gptrPasswordHash or gPasswordHash), (gptrKey or gkey), gNumRounds
		/*
		// simple example that xors 2nd byte of data with 14th byte in the key file
		lea esi,gkey				// put the ADDRESS of gkey into esi
		mov esi,gptrKey;			// put the ADDRESS of gkey into esi (since *gptrKey = gkey)

		lea	esi,gPasswordHash		// put ADDRESS of gPasswordHash into esi
		mov esi,gptrPasswordHash	// put ADDRESS of gPasswordHash into esi (since unsigned char *gptrPasswordHash = gPasswordHash)

		mov al,byte ptr [esi]				// get first byte of password hash
		mov al,byte ptr [esi+4]				// get 5th byte of password hash
		mov ebx,2
		mov al,byte ptr [esi+ebx]			// get 3rd byte of password hash
		mov al,byte ptr [esi+ebx*2]			// get 5th byte of password hash

		mov ax,word ptr [esi+ebx*2]			// gets 5th and 6th bytes of password hash ( gPasswordHash[4] and gPasswordHash[5] ) into ax
		mov eax,dword ptr [esi+ebx*2]		// gets 4 bytes, as in:  unsigned int X = *( (unsigned int*) &gPasswordHash[4] );

		mov al,byte ptr [gkey+ebx]			// get's 3rd byte of gkey[] data

		mov al,byte ptr [gptrKey+ebx]		// THIS IS INCORRECT - will add the address of the gptrKey global variable (NOT the value that gptrKey holds)

		mov al,byte ptr [esi+0xd];			// access 14th byte in gkey[]: 0, 1, 2 ... d is the 14th byte
		mov edi,data				// Put ADDRESS of first data element into edi
		xor byte ptr [edi+1],al		// Exclusive-or the 2nd byte of data with the 14th element of the keyfile
		// NOTE: Keyfile[14] = 0x21, that value changes the case of a letter and flips the LSB
		// Lowercase "c" = 0x63 becomes capital "B" since 0x63 xor 0x21 = 0x42
		*/
		////////////////////////////////////////////////////////
		//	lea esi, gPasswordHash      // put address of gPasswordHash into esi
		//	//mov al, byte ptr[esi]       // put first byte of gPassWordHash into al

		//	mov al, byte ptr[esi]       // move gPasswordHash[0] into ah
		//	shl ax, 8					// multiply first byte of gPasswordHash by 256   gPasswordHash[0] * 256
		//	add ax, word ptr[esi + 1]   // move gPasswordHash [1] into al     ax == starting index

		//	//add bl, al                 // edx is now starting index OR gPassWordHash[0] * 256 + gPassWordHash[
		//	lea esi, gkey				// replace esi with the first byte in gkey     esi == gkey

		//	//loop here
		//	mov edi, data               // move data into edi, this is the address of the first byte of the data file
		//	xor ecx, ecx				// zero out ecx for counting   ecx == counter variable
		//	movzx ebx, ax				// move starting index into ebx for displacement addressing
		//	mov al, byte ptr[esi + ebx]    // put gKey[starting index] into al

		//LOOP1:
		//	xor byte ptr[edi + ecx], al
		//	inc ecx
		//	cmp ecx, dataLength
		//	jne LOOP1

	}

	__asm{
		xor ecx, ecx
		xor ebx, ebx
		mov ecx, gNumRounds
		dec ecx
		mov edi, data					//edi = pointer to data file
	RLOOP:

			
			xor edx, edx					//clears out register for use
			lea esi, gPasswordHash			//save address of gPasswordHash into esi
			mov dh, byte ptr[esi + ecx * 4]			// edx == starting index
			mov dl, byte ptr[esi + 1 + ecx * 4]

			mov bh, byte ptr[esi + 2 + ecx * 4]			// ebx == hop count
			mov bl, byte ptr[esi + 3 + ecx * 4]


			cmp ebx, 0						//check to see if our hop count is zero
			jne	SKIP
			mov ebx, 0xFFFF					//if it IS zero, reset hop count to 0xFFFF


		SKIP:								//if it IS NOT zero, skip the reset

			mov al, gkey[edx]
			push ecx			//save round counter in stack
			xor ecx, ecx		//clear ecx for file loop

		LOOP1:
				
				add edx, ebx									// index += hop count
				cmp edx, 0x10001								//check if index is equal to 65537
				jl SKIP2
				sub edx, 0x10001								//if it is, subtract the index by 65537


			SKIP2 :												//if it is NOT, continue

				push edx										//save index for next loop

				//START STEP B
				ror byte ptr[edi + ecx], 4					//swap nibbles
				//END STEP B

				////START STEP C
				push ecx

				xor edx, edx
				mov dl, byte ptr[edi + ecx]
				xor ecx, ecx
				mov cl, 8
			DopeLOOP:
					rcr dl, 1
					rcl dh, 1
					LOOP DopeLOOP

					pop ecx
					mov byte ptr[edi + ecx], dh
				////END STEP C


				//START STEP D
				xor edx, edx
				mov dl, byte ptr[edi + ecx]					//store byte from data file into al
				and dl, 0x55								//mask odd bits of current byte in data file
				shl dl, 1									//swap the odd bits

				and byte ptr[edi + ecx], 0xAA				//mask even bits of current byte
				shr byte ptr[edi + ecx], 1					//swap the even bits

				or byte ptr[edi + ecx], dl					//combine the two swapped registers
				//END STEP D

				//START STEP A
				ror byte ptr[edi + ecx], 3					//rotate 3 bits to the left
				//END STEP A

				//START STEP E
				xor edx, edx
				mov dl, byte ptr[edi + ecx]					//save byte value to use for encode table index
				mov dl, byte ptr gDecodeTable[edx]		    //replace current byte with corresponding codetable byte
				mov byte ptr[edi + ecx], dl					//replace current file data with value from encode table
				//END STEP E

				xor byte ptr[edi + ecx], al						//milestone #1 XOR

				pop edx											//restore index for next loop
				mov al, gkey[edx]								//update gkey index and get new byte

				inc ecx
				cmp ecx, dataLength
				jb LOOP1


	pop ecx													//retrive round counter from the stack
	dec ecx
	cmp ecx, 0										//check if our current round # is equal to the max # of rounds
	jge RLOOP

	}

	return resulti;
} // decryptData

